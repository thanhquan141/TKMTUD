hello = 'hello'               # String literals can use single quotes
world = "world"               # or double quotes; it does not matter.
print(hello)                  # Prints "hello"
print(len(hello))             # String length; prints "5"
hw = hello + ' ' + world      # String concatenation
print(hw)                     # Prints "hello world"
hw12 = '%s %s %d' % (hello, world, 12)      # sprintf style string formatting
print(hw12)                                 # prints "hello world 12"
hw12 = "{} {} {}".format(hello, world, 12)  # sprintf style string formatting
print(hw12)                                 # prints "hello world 12"