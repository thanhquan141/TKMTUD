# toán tủ
a = 10 
b = 100
print(a + b )
# Hàm thông dụng
# result = pow( 2,10)

# result = round(3.14159265359, 0)
result = round(3.14159265359, 2)
print(result)