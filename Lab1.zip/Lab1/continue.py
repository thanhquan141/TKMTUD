for i in range(10):
    if i == 2:
        print('Ignoring 2')
        continue
    else:
        print(i)