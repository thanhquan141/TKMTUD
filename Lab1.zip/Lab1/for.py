# for i in range(10):
#     print(i)
# for i in [1, 5, 10, 15]:
#     print(i*5)
#Duyệt qua một dictionary dict0 (sẽ được nó rõ ở phần các container)
dict0 = {'One': 1, 'Two': 2, 'Three': 3}
for key, value in dict0.items():
    print(f'key is {key}, value is {value}.')