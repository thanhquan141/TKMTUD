t = True
f = False
print(type(t))
print(t and f)
print(t or f)
print(not f)
print(t != f)    # XOR