a = 1999
b = 2000

if a > b:
    print('a > b')
elif a < b:
    print('a < b')
    if a == 1999:
        print('a = 1999')
    else:
        print('a is not equal to 1999')
else:
    print('a = b')