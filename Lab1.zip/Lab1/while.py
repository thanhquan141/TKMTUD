i = 1
while i < 10:
    print(i*2)
    i = i + 1
print('Mission accomplished!')