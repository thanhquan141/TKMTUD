# a = 1000
# b = 999
# if a > b :
#     print( ' a is greater than b')
a = 2000
b = 2000

# if a < b:
#   print('b is greater than a')
# else:
#   print('a is greater than b')
if b > a:
  print('b is greater than a')
elif a == b:
  print('a and b are equal')
else:
  print('a is greater than b')