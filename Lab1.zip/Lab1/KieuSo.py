x = 3
print(type(x))
print(x)
print(x + 1)
print(x - 1)
print(x * 2)
print(x ** 2)    # power
print(x / 2)     # true division
print(x // 2)    # floor division
print(x % 2)
x += 1
print(x)
x *= 2
print(x)

y = 2.5
print(type(y))
print(y, y + 1, y * 2, y ** 2)